var c = document.getElementById("canvas");
var ctx = c.getContext("2d");
ctx.lineWidth = 3;
ctx.font = "80px Arial";
ctx.fillStyle = '#FFBFCA';
ctx.strokeStyle = '#007F09';
ctx.fillText("Bogomil",5,80);
ctx.strokeText("Bogomil",5,80);

